\c cite;
CREATE EXTENSION postgis;
