This archive is from the GeoServer YSLD Cookbook.

For more information go to:
http://geoserver.org