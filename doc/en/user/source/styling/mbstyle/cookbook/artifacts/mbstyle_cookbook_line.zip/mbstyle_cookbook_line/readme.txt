This archive is from the GeoServer MBStyle Cookbook.

For more information go to:
http://geoserver.org