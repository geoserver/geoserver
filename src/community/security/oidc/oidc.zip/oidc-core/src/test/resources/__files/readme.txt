These resources have been copied and adapted from the demo server used by the 
OpenID Connect Playground:

* https://openidconnect.net/
* https://samples.auth0.com/
